﻿//namespace PlanetMantra.Handlers
//{
public static class Message
{
    public static readonly string Success = "Record saved successfully";
    public static readonly string SuccessFail = "Record not saved";
    public static readonly string Delete = "Record deleted successfully";
    public static readonly string DeleteFail = "Record not found/deleted";
    public static readonly string Found = "Data found";
    public static readonly string NoFound = "No data found";
    public static string Exist(string fieldName) => fieldName + " already exist";
}
//}
