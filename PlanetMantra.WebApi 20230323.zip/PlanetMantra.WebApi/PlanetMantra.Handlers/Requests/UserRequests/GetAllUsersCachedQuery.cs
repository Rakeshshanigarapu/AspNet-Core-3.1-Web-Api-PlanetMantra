﻿using AspNetCoreHero.Results;
using System;
using System.Collections.Generic;
using System.Text;
using PlanetMantra.Domain.Entities;
using MediatR;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using AutoMapper;
using System.Threading.Tasks;
using System.Threading;

namespace PlanetMantra.Handlers.Requests.UserRequests
{
    public class GetAllUsersCachedQuery : IRequest<Result<List<Users>>>
    {
        public class GetAllUsersCachedQueryHandler : IRequestHandler<GetAllUsersCachedQuery, Result<List<Users>>>
        {
            private readonly ICacheRepositoryAsync<Users> _userCache;
            private readonly IMapper _mapper;

            public GetAllUsersCachedQueryHandler(ICacheRepositoryAsync<Users> userCache, IMapper mapper)
            {
                _userCache = userCache;
                _mapper = mapper;
            }

        public async Task<Result<List<Users>>> Handle(GetAllUsersCachedQuery request, CancellationToken cancellationToken)
            {
                var userList = _userCache.GetAllAsync().Result;
                List<Users> mappedUsers = _mapper.Map<List<Users>>(userList);
                // return mappedusers;
                await Task.Delay(100); //100 milliseconds

                string msg = Message.Found;
                if (mappedUsers.Count == 0)
                    msg = Message.NoFound;

                return Result<List<Users>>.Success(mappedUsers, msg);
            }
        }
    }
}
