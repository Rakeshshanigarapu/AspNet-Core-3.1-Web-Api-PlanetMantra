﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.UserRequests
{
    public class AddUserAsync:IRequest<Result<int>>
    {
        public Users user { get; set; }

        public AddUserAsync(Users user)
        {
            this.user = user;
        }
        public class AddUserHandler : IRequestHandler<AddUserAsync, Result<int>>
        {
            private readonly IUserRepository _userRepo;
            private readonly IMapper _mapper;

            public AddUserHandler(IUserRepository userRepo, IMapper mapper)
            {
                _userRepo = userRepo;
                _mapper = mapper;
            }

            public async Task<Result<int>> Handle(AddUserAsync request, CancellationToken cancellationToken)
            {
                var res = _userRepo.AddAsync(request.user).Result;

                await Task.Delay(100); //100 milliseconds
                 
                if (res == 1)
                {
                    //return Result<int>.Success("Record saved Successfully");
                    return Result<int>.Success(Message.Success);
                }
                else if (res == 2)
                { 
                    return Result<int>.Fail(Message.Exist("Email Id"));
                }
                else if (res == 3)
                { 
                    return Result<int>.Fail(Message.Exist("Mobile number"));
                }
                else
                { 
                    return Result<int>.Fail(Message.SuccessFail);
                }

            }
        }
    }
}
