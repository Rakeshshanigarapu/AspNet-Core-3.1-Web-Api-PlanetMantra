﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.UserRequests
{
    public class GetUserByPagingCachedQuery : IRequest<PaginatedResult<GetAllPagedCustomersResponse>>
    {
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public string searchText { get; set; }
        public string sort { get; set; }

        public GetUserByPagingCachedQuery(int pageNumber, int pageSize, string searchText, string sort)
        {
            this.pageNumber = pageNumber;
            this.pageSize = pageSize;
            this.searchText = searchText;
            this.sort = sort;
        }
        public class GetUserByPagingCachedQueryHandler : IRequestHandler<GetUserByPagingCachedQuery, PaginatedResult<GetAllPagedCustomersResponse>>
        {
            private readonly IDataCacheRepository _customerCache;
            private readonly IMapper _mapper;
            private readonly ICacheRepositoryAsync<Users> _userCache;

            public GetUserByPagingCachedQueryHandler(IDataCacheRepository customerCache, IMapper mapper, ICacheRepositoryAsync<Users> userCache)
            {
                _customerCache = customerCache;
                _mapper = mapper;
                _userCache = userCache;
            }

            public async Task<PaginatedResult<GetAllPagedCustomersResponse>> Handle(GetUserByPagingCachedQuery request, CancellationToken cancellationToken)
            {
                var customerList = _userCache.GetAllAsync(request.pageNumber, request.pageSize,request.searchText,request.sort).Result;
                var mappedCustomers = await _mapper.Map<Task<List<GetAllPagedCustomersResponse>>>(customerList.Item1);
                var count = mappedCustomers[0].TotalCount;
                var filteredCount = mappedCustomers[0].FilteredTotalCount;
                //return PaginatedResult<GetAllPagedCustomersResponse>.Success(mappedCustomers, count, request.pageNumber, request.pageSize, request.searchText, request.sort);
                return PaginatedResult<GetAllPagedCustomersResponse>.Success(mappedCustomers, count, request.pageNumber, request.pageSize);

            }

        }
    }
}
