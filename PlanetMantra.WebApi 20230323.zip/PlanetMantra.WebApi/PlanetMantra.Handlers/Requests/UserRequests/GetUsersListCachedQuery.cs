﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.UserRequests
{ 
    public class GetUsersListCachedQuery : IRequest<Result<IList>>
    {
        public class GetUsersListCachedQueryHandler : IRequestHandler<GetUsersListCachedQuery, Result<IList>>
        {
            private readonly ICacheRepositoryAsync<Users> _userCache; 

            public GetUsersListCachedQueryHandler(ICacheRepositoryAsync<Users> userCache)
            {
                _userCache = userCache; 
            }

            public async Task<Result<IList>> Handle(GetUsersListCachedQuery request, CancellationToken cancellationToken)
            {
                var userList = _userCache.GetAllAsyncList().Result;
                await Task.Delay(100); //100 milliseconds

                return Result<IList>.Success(userList.Item1, userList.Item2);
            }
        }
    }
}
