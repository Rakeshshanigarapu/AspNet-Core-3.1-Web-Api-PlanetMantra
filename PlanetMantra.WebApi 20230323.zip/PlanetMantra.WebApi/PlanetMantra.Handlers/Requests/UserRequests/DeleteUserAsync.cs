﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.UserRequests
{
    public class DeleteUserAsync : IRequest<Result<int>>
    {
        public int id{ get; set; }

        public DeleteUserAsync(int id)
        {
            this.id = id;
        }
        public class DeleteUserAsyncHandler : IRequestHandler<DeleteUserAsync, Result<int>>
        {
            private readonly IUserRepository _userRepo;
            private readonly IMapper _mapper;

            public DeleteUserAsyncHandler(IUserRepository userRepo, IMapper mapper)
            {
                _userRepo = userRepo;
                _mapper = mapper;
            }

            public async Task<Result<int>> Handle(DeleteUserAsync request, CancellationToken cancellationToken)
            {
                var res = _userRepo.DeleteAsync(request.id).Result;

                await Task.Delay(100); //100 milliseconds
                 
                if (res == 1)
                { 
                    return Result<int>.Success(Message.Delete);
                }
                else
                { 
                    return Result<int>.Fail(Message.DeleteFail);
                }

            }
        }
    }
}
