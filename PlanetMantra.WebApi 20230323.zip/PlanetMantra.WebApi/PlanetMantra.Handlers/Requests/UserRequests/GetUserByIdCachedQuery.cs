﻿using AspNetCoreHero.Results;
using System;
using System.Collections.Generic;
using System.Text;
using PlanetMantra.Domain.Entities;
using MediatR;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using AutoMapper;
using System.Threading.Tasks;
using System.Threading;

namespace PlanetMantra.Handlers.Requests.UserRequests
{
    public class GetUserByIdCachedQuery : IRequest<Result<Users>>
    {
        public int id { get; set; }

        public GetUserByIdCachedQuery(int id)
        {
            this.id = id; 
        }
        public class GetUserByIdCachedQueryHandler : IRequestHandler<GetUserByIdCachedQuery, Result<Users>>
        {
            private readonly ICacheRepositoryAsync<Users> _userCache;
            private readonly IMapper _mapper;

            public GetUserByIdCachedQueryHandler(ICacheRepositoryAsync<Users> userCache, IMapper mapper)
            {
                _userCache = userCache;
                _mapper = mapper;
            }

        public async Task<Result<Users>> Handle(GetUserByIdCachedQuery request, CancellationToken cancellationToken)
            {
                var user = _userCache.GetByIdAsync(request.id).Result;
                Users mappedUser = _mapper.Map<Users>(user);
                // return mappedusers;
                await Task.Delay(100); //100 milliseconds

                string msg = Message.Found;
                if (mappedUser == null)
                    msg = Message.NoFound;

                return Result<Users>.Success(mappedUser, msg);
            }
        }
    }
}
