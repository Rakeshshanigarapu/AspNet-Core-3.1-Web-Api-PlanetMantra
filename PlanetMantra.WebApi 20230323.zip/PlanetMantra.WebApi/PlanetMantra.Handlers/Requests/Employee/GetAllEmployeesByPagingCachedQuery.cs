﻿using MediatR;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PlanetMantra.Infrastructure.Shared.Results;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.Employee
{
    public class GetAllEmployeesByPagingCachedQuery : IRequest<PaginatedResult<IList>>
    {
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public string searchText { get; set; }

        public GetAllEmployeesByPagingCachedQuery(int pageNumber, int pageSize,string searchText)
        {
            this.pageNumber = pageNumber;
            this.pageSize = pageSize;
            this.searchText = searchText;
        }
        public class GetAllEmployeesByPagingCachedQueryHandler : IRequestHandler<GetAllEmployeesByPagingCachedQuery, PaginatedResult<IList>>
        {
            private readonly IEmployeeCacheRepository _empCache;

            public GetAllEmployeesByPagingCachedQueryHandler(IEmployeeCacheRepository empCache)
            {
                _empCache = empCache;
            }

            public async Task<PaginatedResult<IList>> Handle(GetAllEmployeesByPagingCachedQuery request, CancellationToken cancellationToken)
            {
                var customerList = _empCache.GetAllListAsync(request.pageNumber, request.pageSize,request.searchText).Result;
                var mappedCustomers = customerList.Item1;
                await Task.Delay(100); //100 milliseconds

                var json = System.Text.Json.JsonSerializer.Serialize(mappedCustomers[0]);
                string msg = customerList.Item2 ;
               // var json = JsonConvert.SerializeObject(mappedCustomers[0].ToString(), Formatting.Indented);
                var obj = JObject.Parse(json);
                var count =  (int)obj.SelectToken("totalcount");
                return PaginatedResult<IList>.Success(mappedCustomers, count, request.pageNumber, request.pageSize,request.searchText,msg);
            }
        }
    }
}
