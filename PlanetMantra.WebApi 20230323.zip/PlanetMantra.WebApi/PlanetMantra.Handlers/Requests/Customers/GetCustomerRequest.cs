﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.Customers
{
    public class GetCustomerRequest : IRequest<Result<Customer>>
    {
        public int CustomerId { get; set; }

        public class GetCustomerHandler : IRequestHandler<GetCustomerRequest, Result<Customer>>
        {
            private readonly ICustomerCacheRepository _customerCache;
            private readonly IMapper _mapper;

            public GetCustomerHandler(ICustomerCacheRepository customerCache, IMapper mapper)
            {
                _customerCache = customerCache;
                _mapper = mapper;
            }

            public async Task<Result<Customer>> Handle(GetCustomerRequest customer, CancellationToken cancellationToken)
            {
                var result =   _customerCache.GetByIdAsync(customer.CustomerId).Result;
                Customer mappedCustomer = _mapper.Map<Customer>(result);
                //return mappedCustomer;
                await Task.Delay(100); //100 milliseconds

                string msg = "Data found";
                if (mappedCustomer == null)
                    msg = "No data found";

                return Result<Customer>.Success(mappedCustomer,msg);
            }
        }
    }
}
