﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace PlanetMantra.Handlers.Requests.Customers
{ 
    public class GetAllDataPagination2 : IRequest<PaginatedResult<GetAllCustomersResponse2>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }

        public GetAllDataPagination2(int PageNumber, int PageSize)
        {
            this.PageNumber = PageNumber;
            this.PageSize = PageSize;
        }
    }
    public class GetAllDataPaginationHandler2 : IRequestHandler<GetAllDataPagination2, PaginatedResult<GetAllCustomersResponse2>>
    {
        private readonly IDataCacheRepository _customerCache;
        private readonly IMapper _mapper;

        public GetAllDataPaginationHandler2(IDataCacheRepository customerCache, IMapper mapper)
        {
            _customerCache = customerCache;
            _mapper = mapper;
        }

        public async Task<PaginatedResult<GetAllCustomersResponse2>> Handle(GetAllDataPagination2 request, CancellationToken cancellationToken)
        {
            var customerList = _customerCache.GetCachedListAsync(request.PageNumber, request.PageSize);
            var items = customerList.Result;
            var count = items[0].TotalCount;

            List<GetAllCustomersResponse2> objCustomers = new List<GetAllCustomersResponse2>();

            foreach (var item in items)
            {
                GetAllCustomersResponse2 obj = new GetAllCustomersResponse2();
                obj.Id = item.Id;
                obj.Name = item.Name;
                obj.Phone = item.Phone;
                obj.Email = item.Email;
                obj.Address = item.Address;
                objCustomers.Add(obj);
            }


            var mappedCustomers = await _mapper.Map<Task<List<GetAllCustomersResponse2>>>(objCustomers);
            
            return PaginatedResult<GetAllCustomersResponse2>.Success(mappedCustomers, count, request.PageNumber, request.PageSize);
        }
         
    }
}
