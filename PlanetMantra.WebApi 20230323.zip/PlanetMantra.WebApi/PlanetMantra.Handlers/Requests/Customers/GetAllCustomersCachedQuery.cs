﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.Customers
{
    public class GetAllCustomersCachedQuery : IRequest<Result<List<Customer>>>
    {
        public class GetAllCustomersCachedQueryHandler : IRequestHandler<GetAllCustomersCachedQuery, Result<List<Customer>>>
        {
            private readonly ICustomerCacheRepository _customerCache;
            private readonly IMapper _mapper;

            public GetAllCustomersCachedQueryHandler(ICustomerCacheRepository customerCache, IMapper mapper)
            {
                _customerCache = customerCache;
                _mapper = mapper;
            }

            public async Task<Result<List<Customer>>> Handle(GetAllCustomersCachedQuery request, CancellationToken cancellationToken)
            {
                var customerList =  _customerCache.GetCachedListAsync().Result;
                List<Customer> mappedCustomers =   _mapper.Map<List<Customer>>(customerList);
                // return mappedCustomers;
                await Task.Delay(100); //100 milliseconds

                string msg = "Data found";
                if (mappedCustomers.Count == 0)
                    msg = "No data found";

                return  Result<List<Customer>>.Success(mappedCustomers,msg);
            }
        }
    }
}
