﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.Customers
{ 
    public class GetAllDataPagination : IRequest<PaginatedResult<GetAllCustomersResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }

        public GetAllDataPagination(int PageNumber, int PageSize)
        {
            this.PageNumber = PageNumber;
            this.PageSize = PageSize;
        }
    }
    public class GetAllDataPaginationHandler : IRequestHandler<GetAllDataPagination, PaginatedResult<GetAllCustomersResponse>>
    {
        private readonly IDataCacheRepository _customerCache;
        private readonly IMapper _mapper;

        public GetAllDataPaginationHandler(IDataCacheRepository customerCache, IMapper mapper)
        {
            _customerCache = customerCache;
            _mapper = mapper;
        }

        public async Task<PaginatedResult<GetAllCustomersResponse>> Handle(GetAllDataPagination request, CancellationToken cancellationToken)
        {
            var customerList = _customerCache.GetCachedListAsync(request.PageNumber, request.PageSize);
            var mappedCustomers = await _mapper.Map<Task<List<GetAllCustomersResponse>>>(customerList);
            var count = mappedCustomers[0].TotalCount; 
            return PaginatedResult<GetAllCustomersResponse>.Success(mappedCustomers, count, request.PageNumber, request.PageSize);

        }
         
    }
}
