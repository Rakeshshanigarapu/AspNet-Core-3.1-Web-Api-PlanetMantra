﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.Customers
{
    public class GetUserRequestCachedQuery : IRequest<string>
    {
        public class GetUserRequestCachedQueryHandler : IRequestHandler<GetUserRequestCachedQuery, string>
        {
            public async Task<string> Handle(GetUserRequestCachedQuery request, CancellationToken cancellationToken)
            {
                var result = "Rocky class";
                return await Task.FromResult(result);
            }
        }
    }
}
