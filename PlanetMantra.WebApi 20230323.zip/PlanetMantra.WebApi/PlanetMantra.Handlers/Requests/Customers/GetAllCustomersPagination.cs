﻿using AspNetCoreHero.Results;
using AutoMapper;
using MediatR;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PlanetMantra.Handlers.Requests.Customers
{   
    public class GetAllCustomersPagination : IRequest<PaginatedResult<Customer>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }

        public GetAllCustomersPagination(int PageNumber, int PageSize)
        {
            this.PageNumber = PageNumber;
            this.PageSize = PageSize;
        }
    }
    public class GetAllCustomersPaginationHandler : IRequestHandler<GetAllCustomersPagination, PaginatedResult<Customer>>
    {
        private readonly ICustomerCacheRepository _customerCache;
        private readonly IMapper _mapper;

        public GetAllCustomersPaginationHandler(ICustomerCacheRepository customerCache, IMapper mapper)
        {
            _customerCache = customerCache;
            _mapper = mapper;
        }

        public async Task<PaginatedResult<Customer>> Handle(GetAllCustomersPagination request, CancellationToken cancellationToken)
        { 
            var customerList =   _customerCache.GetCachedListAsync(request.PageNumber,request.PageSize).Result;
            //var mappedCustomers = await _mapper.Map<Task<PaginatedResult<Customer>>>(customerList);
            var count= 0;
            if (customerList.Count != 0)
                count = customerList[0].TotalCount;
            await Task.Delay(100); //100 milliseconds
            return PaginatedResult<Customer>.Success(customerList, count, request.PageNumber, request.PageSize);
           
        }
    }
}
