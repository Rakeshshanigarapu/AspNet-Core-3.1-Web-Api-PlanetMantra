﻿using PlanetMantra.Infrastructure.Shared.DTOs.Mail;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Infrastructure.Shared.Interface
{
    public interface IMailService
    {
        Task<bool> SendAsync(MailRequest request);
    }
}
