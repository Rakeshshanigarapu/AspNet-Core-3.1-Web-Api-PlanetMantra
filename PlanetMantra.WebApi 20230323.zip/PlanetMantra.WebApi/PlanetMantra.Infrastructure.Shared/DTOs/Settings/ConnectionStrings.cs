﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Infrastructure.Shared.DTOs.Settings
{
    public class ConnectionStrings
    {
        public string ConnectionString { get; set; }
    }
}
