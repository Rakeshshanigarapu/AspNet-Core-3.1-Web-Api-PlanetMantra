﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace PlanetMantra.Infrastructure.Shared.DTOs.Mail
{
    public class MailRequest
    {
        /// <summary>
        /// The TO field is, according to the rules of email etiquette, meant for the main recipient(s) of your email.
        /// A semicolon to separate multiple email recipients.
        /// Ex: abc@xyz.com;pqr@xyz.com;mno@xyz.com
        /// </summary>
        public string To { get; set; }
        /// <summary>
        /// An email subject line is the first text recipients see after your sender name when an email reaches their inbox.
        /// </summary>
        public string Subject { get; set; }
        /// <summary>
        /// The body is the actual text of the email.
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        /// The message is the person who sent it.
        /// </summary>
        public string From { get; set; }
        /// <summary>
        /// An email attachment is a computer file sent along with an email message.
        /// </summary>
        public IFormFileCollection Attachments { get; set; }
        /// <summary>
        /// Cc stands for carbon copy.
        /// A semicolon to separate multiple email recipients.
        /// Ex: abc@xyz.com;pqr@xyz.com;mno@xyz.com
        /// </summary>
        public string Cc { get; set; }
        /// <summary>
        /// Bcc stands for blind carbon copy.
        /// A semicolon to separate multiple email recipients.
        /// Ex: abc@xyz.com;pqr@xyz.com;mno@xyz.com
        /// </summary>
        public string Bcc { get; set; }
    }
}
