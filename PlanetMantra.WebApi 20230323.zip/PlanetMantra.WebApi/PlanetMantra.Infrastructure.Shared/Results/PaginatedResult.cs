﻿using System;
using System.Collections.Generic;

namespace PlanetMantra.Infrastructure.Shared.Results
{
    public class PaginatedResult<T> : Result
    {
        public PaginatedResult(T data)
        {
            Data = data;
        }
        public T Data { get; set; }
        public string Sort { get; set; }
        public string SearchText { get; set; }
       // publicstring message { get; set; }
      /*  internal PaginatedResult(bool succeeded, T data = default,string message = null)
        {
            Data = data; 
            Succeeded = succeeded;  
        }
        internal PaginatedResult(bool succeeded, T data = default,string message = null, long count = 0, int page = 1, int pageSize = 10)
        {
            Data = data;
            Page = page;
            Succeeded = succeeded;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            TotalCount = count;

            Message = message;
        }
        internal PaginatedResult(bool succeeded, T data = default,string message = null, long count = 0, int page = 1, int pageSize = 10,  string searchText = "")
        {
            Data = data;
            Page = page;
            Succeeded = succeeded;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            TotalCount = count;
            Message = message; 
            SearchText = searchText;
        }
        */
        internal PaginatedResult(bool succeeded, T data = default,string message = null, long count = 0, int page = 1, int pageSize = 10, string searchText = "", string sort = "")
        {
            Data = data;
            Page = page;
            Succeeded = succeeded;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            TotalCount = count;
            Message = message; 
            Sort = sort;
            SearchText = searchText;
        } 
        public static PaginatedResult<T> Failure(string message)
        {
            return new PaginatedResult<T>(false,default, message);
        }
        public static PaginatedResult<T> Success(T data, long count, int page, int pageSize)
        {
            return new PaginatedResult<T>(true, data, null, count, page, pageSize);
        }       
        public static PaginatedResult<T> Success(T data, long count, int page, int pageSize,string message)
        {
            return new PaginatedResult<T>(true, data, message, count, page, pageSize);
        }
        public static PaginatedResult<T> Success(T data, long count, int page, int pageSize, string searchText,string message)
        {
            return new PaginatedResult<T>(true, data, message, count, page, pageSize,  searchText);
        }
        //public static PaginatedResult<T> Success(T data, long count, int page, int pageSize, string sort, string searchText)
        //{
        //    return new PaginatedResult<T>(true, data, null, count, page, pageSize, sort, searchText);
        //}
        public static PaginatedResult<T> Success(T data, long count, int page, int pageSize, string sort, string searchText,string message)
        {
            return new PaginatedResult<T> (true,data,message, count,page,pageSize,sort,searchText );
        }

        public int Page { get; set; }

        public int TotalPages { get; set; }

        public long TotalCount { get; set; } 

        public bool HasPreviousPage => Page > 1;

        public bool HasNextPage => Page < TotalPages;
    }
}
