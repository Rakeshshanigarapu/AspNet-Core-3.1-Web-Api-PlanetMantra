﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Infrastructure.Shared.Results
{
    public interface IResult
    {
        string Message { get; set; }

        bool Succeeded { get; set; }
    }

    public interface IResult<out T> : IResult
    {
        T Data { get; }
    }
}
