﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using MimeKit;
using PlanetMantra.Infrastructure.Shared.DTOs.Mail;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using PlanetMantra.Infrastructure.Shared.Interface;
using PlanetMantra.LoggerService.Repositories;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Infrastructure.Shared.Services
{
    public class SMTPMailService : IMailService
    {
        public MailSettings _mailSettings { get; }
        // public ILogger<SMTPMailService> _logger { get; }
        public ILoggerService _logger;
        public SMTPMailService(IOptions<MailSettings> mailSettings, ILoggerService logger)
        {
            _mailSettings = mailSettings.Value;
            _logger = logger;
        }

        public async Task<bool> SendAsync(MailRequest request)
        {
            try
            {
                _logger.LogInfo("Fetching MailRequest");
                var email = new MimeMessage();
                email.Sender = MailboxAddress.Parse(request.From ?? _mailSettings.EmailId);
                // email.To.Add(MailboxAddress.Parse(request.To));
                // email.Cc.Add(MailboxAddress.Parse(request.CC));
                if (request.To != null)
                {
                    string[] emailToAddress = request.To.Split(';');
                    if (emailToAddress.Length > 0)
                    {
                        InternetAddressList list = new InternetAddressList();
                        foreach (var emailaddres in emailToAddress)
                        {
                            list.Add(MailboxAddress.Parse(emailaddres));
                        }
                        email.To.AddRange(list);
                    }
                }
                if (request.Cc != null)
                {
                    string[] emailCcAddress = request.Cc.Split(';');
                    if (emailCcAddress.Length > 0)
                    {
                        InternetAddressList list = new InternetAddressList();
                        foreach (var emailaddres in emailCcAddress)
                        {
                            list.Add(MailboxAddress.Parse(emailaddres));
                        }
                        email.Cc.AddRange(list);
                    }
                }
                if (request.Bcc != null)
                {
                    string[] emailBccAddress = request.Bcc.Split(';');
                    if (emailBccAddress.Length > 0)
                    {
                        InternetAddressList list = new InternetAddressList();
                        foreach (var emailaddres in emailBccAddress)
                        {
                            list.Add(MailboxAddress.Parse(emailaddres));
                        }
                        email.Bcc.AddRange(list);
                    }
                }
                email.Subject = request.Subject;
                var emailBodyBuilder = new BodyBuilder();

                if (request.Attachments != null)
                {
                    byte[] attachmentFileByteArray;
                    foreach (IFormFile attachmentFile in request.Attachments)
                    {
                        if (attachmentFile.Length > 0)
                        {
                            using (MemoryStream memoryStream = new MemoryStream())
                            {
                                attachmentFile.CopyTo(memoryStream);
                                attachmentFileByteArray = memoryStream.ToArray();
                            }
                            emailBodyBuilder.Attachments.Add(attachmentFile.FileName, attachmentFileByteArray, ContentType.Parse(attachmentFile.ContentType));
                        }
                    }
                }

                emailBodyBuilder.HtmlBody = request.Body;
                email.Body = emailBodyBuilder.ToMessageBody();

                using var smtp = new SmtpClient();
                 smtp.Connect(_mailSettings.Host, _mailSettings.Port, SecureSocketOptions.StartTls);
               // smtp.Connect(_mailSettings.Host, _mailSettings.Port, _mailSettings.UseSSL);
                smtp.Authenticate(_mailSettings.EmailId, _mailSettings.Password);
                await smtp.SendAsync(email);
                smtp.Disconnect(true);
                smtp.Dispose();
                _logger.LogInfo("Mail sent.");
                return true;
            }
            catch (System.Exception ex)
            {
                string msg = "";
                if (ex.Message != null)
                {
                    msg = ex.Message.ToString(); 
                }
                else
                {
                    msg = ex.InnerException.Message.ToString();
                } 
                _logger.LogError(msg);
                return false;
            }
        }
    }
}
