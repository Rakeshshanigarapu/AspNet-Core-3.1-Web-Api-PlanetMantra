﻿using Microsoft.AspNetCore.Http;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PlanetMantra.Infrastructure.Shared.Extensions
{
    public static class FormFileExtensions
    {
        public static byte[] OptimaizeImageSizeInByteArray(this IFormFile file, int maxWidth, int maxHeight)
        {
            using (var stream = file.OpenReadStream())
            using (var image = Image.Load(stream))
            {
                using (var writeStream = new MemoryStream())
                {
                    NewImageSize(maxWidth, maxHeight, image);
                    image.SaveAsJpeg(writeStream);   // image.SaveAsPng(writeStream);
                    return writeStream.ToArray();
                }
            }

        }

        public static void OptimaizeImageSizeInImage(this IFormFile file, int maxWidth, int maxHeight, string fullPath)
        {
            using (var stream = file.OpenReadStream())
            using (var image = Image.Load(stream))
            {
                NewImageSize(maxWidth, maxHeight, image);
                image.Save(fullPath);
            }

        }

        private static void NewImageSize(int maxWidth, int maxHeight, Image image)
        {
            if (image.Width > maxWidth)
            {
                string newSize = ResizeImage(image, maxWidth, maxHeight);
                string[] aSize = newSize.Split(',');
                image.Mutate(i => i.Resize(Convert.ToInt32(aSize[1]), Convert.ToInt32(aSize[0])));
            }
        }
        private static string ResizeImage(Image img, int maxWidth, int maxHeight)
        {
            if (img.Width > maxHeight || img.Height > maxHeight)
            {
                double widthRatio = (double)img.Width / (double)maxWidth;
                double heightRatio = (double)img.Height / (double)maxHeight;
                double ratio = Math.Max(widthRatio, heightRatio);
                int newwidth = (int)(img.Width / ratio);
                int newHeight = (int)(img.Height / ratio);
                return newHeight.ToString() + "," + newwidth.ToString();
            }
            else
            {
                return img.Height.ToString() + "," + img.Width.ToString();
            }
        }

    }
}
