﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;

namespace PlanetMantra.Infrastructure.Shared
{
    public static class CachingExtension
    {
        public static async Task<T> GetAsync<T>(this IDistributedCache distributedCache,string cacheKey, CancellationToken token=default )
        {
           // byte[] utf8Bytes = await distributedCache.GetAsync(cacheKey, token).ConfigureAwait(false);

            byte[] utf8Bytes = await distributedCache.GetAsync(cacheKey);
            if (utf8Bytes != null)
            {
                var jsonToDeserialize = System.Text.Encoding.UTF8.GetString(utf8Bytes);
                var res= JsonSerializer.Deserialize<T>(utf8Bytes);
                return res;
            }
            return default;
        }
        public static async Task SetAsync<T>(this IDistributedCache distributedCache, string cacheKey, T obj, int setSlidingExpirationInMinutes = 1,int setAbsoluteExpirationInMinutes = 5, CancellationToken token = default)
        {
            DistributedCacheEntryOptions options = new DistributedCacheEntryOptions()
                .SetSlidingExpiration(TimeSpan.FromMinutes(setSlidingExpirationInMinutes))
                .SetAbsoluteExpiration(TimeSpan.FromMinutes(setAbsoluteExpirationInMinutes));
            byte[] utf8Bytes = JsonSerializer.SerializeToUtf8Bytes<T>(obj);
            // await distributedCache.SetAsync(cacheKey, utf8Bytes, options, token).ConfigureAwait(false);
            await distributedCache.SetAsync(cacheKey, utf8Bytes, options, token);
        }
        public static async Task RemoveAsync(this IDistributedCache distributedCache, string cacheKey, CancellationToken token = default)
        {
            //await distributedCache.RemoveAsync(cacheKey, token).ConfigureAwait(false);
            await distributedCache.RemoveAsync(cacheKey, token);
        }
    }
}
