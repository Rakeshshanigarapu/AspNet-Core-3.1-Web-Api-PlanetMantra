﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace PlanetMantra.Infrastructure.Shared.Extensions
{
    public class SerializerDeserializerExtensions
    {
        /// <summary>
        /// Convert an object to a byte array
        /// </summary>
        /// <param name="obj">Object</param>
        /// <returns>byte[] </returns>
        public byte[] ObjectToByteArray(Object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);

            return ms.ToArray();
        }
        public T ByteArrayToObject<T>(byte[] arrBytes)
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            ms.Write(arrBytes, 0, arrBytes.Length);
            ms.Seek(0, SeekOrigin.Begin);
            T obj = (T)bf.Deserialize(ms);

            return obj;
        }

        public Object ByteArrayToObject(byte[] arrBytes)
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            ms.Write(arrBytes, 0, arrBytes.Length);
            ms.Seek(0, SeekOrigin.Begin);
            Object obj = (Object)bf.Deserialize(ms);

            return obj;
        }
    }
}
