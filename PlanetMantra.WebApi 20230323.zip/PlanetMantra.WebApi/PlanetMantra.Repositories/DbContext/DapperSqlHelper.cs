﻿using Dapper;
using Microsoft.Extensions.Options;
using Npgsql;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace PlanetMantra.Repository.DbContext
{
    public static class DapperSqlHelper
    {
        #region Connection String & Timeout
        private static string _connectionString=null;
       
        internal static IDbConnection Connection
        {
            get
            {
                return new NpgsqlConnection(_connectionString);
            }
        }
        public static string GetConnectionString(string connectionString = null)
        { 
            return connectionString; 
        }
        public static int ConnectionTimeout { get; set; }

        public static int GetTimeout(int? commandTimeout = null)
        {
            if (commandTimeout.HasValue)
                return commandTimeout.Value;

            return ConnectionTimeout;
        }
        #endregion

        public static IEnumerable<T> FindAll<T>(string connectionString)
        {
            GetConnectionString(connectionString);
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                return dbConnection.Query<T>("SELECT * FROM customer");
            }
        }

    }
}
