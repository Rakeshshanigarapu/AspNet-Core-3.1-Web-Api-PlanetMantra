﻿using PlanetMantra.Domain.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public interface IUserRepository
    {
        Task<Users> GetByIdAsync(int id);

        Task<List<Users>> GetAllAsync();

        Task<IList> GetAllAsyncList();

        Task<List<Users>> GetAllAsync(int pageNumber, int pageSize);

        Task<int> AddAsync(Users entity);

        Task<int> UpdateAsync(Users entity);

        Task<int> DeleteAsync(int id);

        Task<IList> GetUserPagedReponseAsync(int pageNumber, int pageSize, string searchText, string sort);
    }
}
