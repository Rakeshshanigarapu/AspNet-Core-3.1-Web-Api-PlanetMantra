﻿
using System.Collections;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public interface IDropdownsRepositoryAsync
    {
        Task<IList> GetDepartments();
    }
}
