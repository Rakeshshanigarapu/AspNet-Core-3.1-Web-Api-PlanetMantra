﻿
using System.Collections;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public  interface IEmployeeRepositoryAsync
    {
        Task<IList> GetNewEmployeeNumber();
        Task<IList> IsValidUserName(string userName);
        Task<IList> IsValidEmployeeNumber(int empNo);
        Task<IList> GetAllEmployees(int pageNumber, int pageSize, string searchText);
    }
}
