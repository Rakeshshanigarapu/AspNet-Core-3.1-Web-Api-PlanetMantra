﻿using PlanetMantra.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public interface ICustomerRepository
    {
        Task<Customer> GetByIdAsync(int id);

        Task<List<Customer>> GetAllAsync();

        Task<List<Customer>> GetAllAsync(int pageNumber, int pageSize);

        Task<int> AddAsync(Customer entity);

        Task<Customer> UpdateAsync(Customer entity);

        Task<int> DeleteAsync(int id); 
    }
}
