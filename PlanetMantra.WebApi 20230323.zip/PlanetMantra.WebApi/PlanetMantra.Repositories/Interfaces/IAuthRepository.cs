﻿using PlanetMantra.Domain.Entities;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public interface IAuthRepository
    {
        Task<UserModel> GetLoginUser(string username,string password);
    }
}
