﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
   /* public interface IGenericRepositoryAsync<T> where T : class
    { 
        Task<int> AddAsync(string sql, T entity);

        Task<int> UpdateAsync(string sql, T entity);

        Task<int> DeleteAsync(string sql, int id);

        Task<IList> GetByIdAsync(string sql, int id);

        Task<IList> GetAllAsync(string sql);

        Task<IList> GetPagedReponseAsync(string sql, int pageNumber, int pageSize);
    }
    public interface IGenericRepositoryListAsync
    {
        Task<IList> GetByIdAsync(string sql, int id);

        Task<IList> GetAllAsync(string sql);

        Task<IList> GetPagedReponseAsync(string sql, int pageNumber, int pageSize); 
    }
    */
}
