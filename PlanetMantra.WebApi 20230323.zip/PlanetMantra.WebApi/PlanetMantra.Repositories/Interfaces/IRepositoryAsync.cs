﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public interface IRepositoryAsync<T>: IDisposable where T : class
    {
        Task<T> GetByIdAsync(string sql, int id);

        Task<List<T>> GetAllAsync(string sql);
         Task<IList> GetAllAsyncList(string sql);

        //Task<List<T>> GetPagedReponseAsync(int pageNumber, int pageSize);
        Task<List<T>> GetPagedReponseAsync(string sql);

        Task<int> AddAsync(string sql, T entity);

        Task<T> UpdateAsync(string sql, T entity);
        Task<int> Update(string sql, T entity);

        Task<int> DeleteAsync(string sql, int id);
    }
}
