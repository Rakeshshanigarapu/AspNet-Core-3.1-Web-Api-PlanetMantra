﻿using PlanetMantra.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Interfaces
{
    public interface IDataRepository
    {
        Task<List<GetAllCustomersResponse>> GetAllAsync(int pageNumber, int pageSize);
    }
}
