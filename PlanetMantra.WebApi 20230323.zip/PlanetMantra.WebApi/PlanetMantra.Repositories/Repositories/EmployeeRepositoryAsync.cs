﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Repositories
{
    public class EmployeeRepositoryAsync: IEmployeeRepositoryAsync
    {
        private readonly IDistributedCache _distributedCache;
        private readonly IGenericRepositoryIListAsync _repository;
        public EmployeeRepositoryAsync(IDistributedCache distributedCache, IGenericRepositoryIListAsync repositoryAsync)
        {
            _distributedCache = distributedCache;
            _repository = repositoryAsync;
        }
        public async Task<IList> GetNewEmployeeNumber()
        {
            string query = string.Format(@"select * from public.fungetemp_no()");
            return await _repository.GetAsync(query);
        }
        public async Task<IList> IsValidUserName(string userName)
        {
            string query = string.Format(@"select * from public.funGetValidUserName('{0}')", userName);
            return await _repository.GetAsync(query);
        }
        public async Task<IList> IsValidEmployeeNumber(int empNo)
        {
            string query = string.Format(@"select * from public.funGetValidEmployeeNumber('{0}')", empNo);
            return await _repository.GetAsync(query);
        }
        public async Task<IList> GetAllEmployees(int pageNumber, int pageSize, string searchText)
        {
            string query = string.Format(@"select * from public.fungetemployees({0},{1},'{2}')",pageNumber,pageSize,searchText);
            return await _repository.GetAsync(query);
        } 
    }
}
