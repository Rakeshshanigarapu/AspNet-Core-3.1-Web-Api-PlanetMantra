﻿using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Extensions.Configuration;
using System.Data;
using Npgsql;
using Dapper;
using Microsoft.Extensions.Options;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using PlanetMantra.Repository.DbContext;
using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.CacheKeys;

namespace PlanetMantra.Repository.Repositories
{
    public class CustomerRepository: ICustomerRepository
    {
        private readonly IRepositoryAsync<Customer> _repository;
        private readonly IDistributedCache _distributedCache;

        public CustomerRepository(IDistributedCache distributedCache, IRepositoryAsync<Customer> repository)
        {
            _distributedCache = distributedCache;
            _repository = repository;
        }

        public async Task<int> AddAsync(Customer entity)
        {   
            var res= await _repository.AddAsync("INSERT INTO customer (name,phone,email,address) VALUES(@Name,@Phone,@Email,@Address)", entity);
            await _distributedCache.RemoveAsync(CustomerCacheKeys.ListKey);
            return res;
        }

        public async Task<int> DeleteAsync(int id)
        {
            await _distributedCache.RemoveAsync(CustomerCacheKeys.ListKey);
            await _distributedCache.RemoveAsync(CustomerCacheKeys.GetKey(id));
            return await _repository.DeleteAsync("DELETE FROM customer WHERE Id=@Id", id);
        }

        public async Task<List<Customer>> GetAllAsync()
        {
            return await _repository.GetAllAsync("SELECT * FROM customer");
        }
        public async Task<List<Customer>> GetAllAsync(int pageNumber, int pageSize)
        {
            string query = string.Format("select *,Count(*) Over () AS TotalCount from  customer order by id OFFSET({0} - 1) * {1} FETCH NEXT {1} ROWS ONLY; ", pageNumber, pageSize);
            return await _repository.GetAllAsync(query);
        }

        public async Task<Customer> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync("SELECT * FROM customer WHERE id = @Id", id);
        }

        public async Task<Customer> UpdateAsync(Customer entity)
        {
            await _distributedCache.RemoveAsync(CustomerCacheKeys.ListKey);
            await _distributedCache.RemoveAsync(CustomerCacheKeys.GetKey(entity.Id));
            return await  _repository.UpdateAsync("UPDATE customer SET name = @Name,  phone  = @Phone, email= @Email, address= @Address WHERE id = @Id", entity);
        }
    }
}
