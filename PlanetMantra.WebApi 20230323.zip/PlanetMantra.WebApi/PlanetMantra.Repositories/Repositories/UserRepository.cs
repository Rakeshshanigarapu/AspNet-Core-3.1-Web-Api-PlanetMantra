﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.CacheKeys;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IDistributedCache _distributedCache;
        private readonly IRepositoryAsync<Users> _repository;
        private readonly IRepositoryAsync<GetAllPagedCustomersResponse> _repository2;

        public UserRepository(IDistributedCache distributedCache,IRepositoryAsync<Users> repositoryAsync, IRepositoryAsync<GetAllPagedCustomersResponse> repository2)
        {
            _distributedCache = distributedCache;
            _repository = repositoryAsync;
            _repository2 = repository2;
        }
        public async Task<int> AddAsync(Users entity)
        {
            var res = await _repository.AddAsync("select * from public.FunSaveUser(@Id,@Name,@EmailId,@Mobile,@Address)", entity);
            await _distributedCache.RemoveAsync(UserCacheKeys.ListKey);
            return res;
        }

        public async Task<int> DeleteAsync(int id)
        {
            await _distributedCache.RemoveAsync(CustomerCacheKeys.ListKey);
            await _distributedCache.RemoveAsync(CustomerCacheKeys.GetKey(id));
            return await _repository.DeleteAsync("select * from FunDeleteUser(@Id)", id);
        }

        public async Task<List<Users>> GetAllAsync()
        {
            return await _repository.GetAllAsync("select * from FunGetUsers()");
        }
        public async Task<IList> GetAllAsyncList()
        {
            return await _repository.GetAllAsyncList("select * from FunGetUsers()");
        }

        public async Task<List<Users>> GetAllAsync(int pageNumber, int pageSize)
        {
            string query = string.Format("select *,Count(*) Over () AS TotalCount from  FunGetUsers() order by id OFFSET({0} - 1) * {1} FETCH NEXT {1} ROWS ONLY; ", pageNumber, pageSize);
            return await _repository.GetAllAsync(query);
        }

        public async Task<Users> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync("select * from FunGetUserById(@Id)", id);
        }

        public async Task<int> UpdateAsync(Users entity)
        {
            await _distributedCache.RemoveAsync(CustomerCacheKeys.ListKey);
            await _distributedCache.RemoveAsync(CustomerCacheKeys.GetKey(entity.Id));
            return await _repository.Update("select * from public.FunSaveUser(@Id,@Name,@EmailId,@Mobile,@Address)", entity);
        }

        public async Task<IList> GetUserPagedReponseAsync(int pageNumber, int pageSize,string searchText,string sort)
        {
            searchText = searchText == null ? "" : searchText;
            sort = sort == null ? "" : sort;
            sort = sort == "" ? "id asc" : sort;
            string query = string.Format(@"select * 
                                            ,Count(1) Over () AS FilteredTotalCount
                                            ,(select  Count(1) from  customer)AS TotalCount 
                                            from customer
                                            where cast(name as varchar) like '%{2}%'
                                            order by {3} OFFSET({0} - 1) * {1} FETCH NEXT {1} ROWS ONLY; ", pageNumber, pageSize, searchText,sort);
            //var result = await _repository2.GetPagedReponseAsync(query);
            var result = await _repository2.GetAllAsyncList(query);

            return result;
        }
    }
}
