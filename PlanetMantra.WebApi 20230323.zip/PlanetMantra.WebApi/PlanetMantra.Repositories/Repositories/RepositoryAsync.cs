﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Npgsql;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using System.Collections;

namespace PlanetMantra.Repository.Repositories
{
    public class RepositoryAsync<T> : IRepositoryAsync<T> where T : class
    {
        private readonly string connectionString;
      //  private readonly IConfiguration connectionString;

         public RepositoryAsync(IOptions<ConnectionStrings> connectionString)
         {
             this.connectionString = connectionString.Value.ConnectionString;
         }
         
      /*  public RepositoryAsync(IConfiguration connectionString)
        {
            this.connectionString = connectionString.GetValue();
        }
      */
        internal IDbConnection Connection
        {
            get
            {
                return new NpgsqlConnection(connectionString);
            }
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="sql">"INSERT INTO customer (name,phone,email,address) VALUES(@Name,@Phone,@Email,@Address)"</param>
        /// <param name="entity">class</param>
        /// <returns>int</returns>
        public async Task<int> AddAsync(string sql,T entity)
        {
            // await _dbContext.Set<T>().AddAsync(entity);
            //return entity;
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                // var result = await dbConnection.ExecuteAsync(sql, entity);
                var result = await dbConnection.ExecuteScalarAsync(sql, entity);
                return  (int)result;
            } 
        }
        /// <summary>
        /// Delete record
        /// </summary>
        /// <param name="sql">"DELETE FROM customer WHERE Id=@Id"</param>
        /// <param name="id">id</param>
        /// <returns>int</returns>
        public async Task<int> DeleteAsync(string sql, int id)
        {
            // _dbContext.Set<T>().Remove(entity);
            // return Task.CompletedTask; 
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                //var result = await dbConnection.ExecuteAsync(sql, new { Id = id });
                var result = await dbConnection.ExecuteScalarAsync(sql, new { Id = id });
                return (int)result;
            }
        }
        /// <summary>
        /// Get all recoreds
        /// </summary>
        /// <param name="sql">SELECT * FROM customer</param>
        /// <returns>list</returns>
        public async Task<List<T>> GetAllAsync(string sql)
        {
            //return await _dbContext
            //    .Set<T>()
            //    .ToListAsync();
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                var res = await dbConnection.QueryAsync<T>(sql);

                return res.ToList();
            }
        }
        public async Task<IList> GetAllAsyncList(string sql)
        {
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                var res = await dbConnection.QueryAsync(sql);

                return res.ToList();
            }
        }
        /// <summary>
        /// Get record by id
        /// </summary>
        /// <param name="sql">SELECT * FROM customer WHERE id = @Id</param>
        /// <param name="id">id</param>
        /// <returns>singe record</returns>
        public async Task<T> GetByIdAsync(string sql,int id)
        {
            // return await _dbContext.Set<T>().FindAsync(id);
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                var res= await dbConnection.QueryAsync<T>(sql, new { Id = id });
                return res.FirstOrDefault();
            }
        }
        /// <summary>
        /// Get record by id
        /// </summary>
        /// <param name="sql">SELECT * FROM customer</param> 
        /// <returns>singe record</returns>
        public async Task<List<T>> GetPagedReponseAsync(string sql)
        { 
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                var res = await dbConnection.QueryAsync<T>(sql);

                return res.ToList();
            }
        }

        /*public async Task<List<T>> GetPagedReponseAsync(int pageNumber, int pageSize)
        {
            return await _dbContext
                .Set<T>()
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .AsNoTracking()
                .ToListAsync();
        }
         */



        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql">"UPDATE customer SET name = @Name,  phone  = @Phone, email= @Email, address= @Address WHERE id = @Id"</param>
        /// <param name="entity">class</param>
        /// <returns>class</returns>
        public async Task<T> UpdateAsync(string sql,T entity)
        {
            //_dbContext.Entry(entity).CurrentValues.SetValues(entity);
            //return Task.CompletedTask;

            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
               var res= await dbConnection.QueryAsync(sql, entity); 
                return entity;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql">"UPDATE customer SET name = @Name,  phone  = @Phone, email= @Email, address= @Address WHERE id = @Id"</param>
        /// <param name="entity">class</param>
        /// <returns>class</returns>
        public async Task<int> Update(string sql, T entity)
        {
            //_dbContext.Entry(entity).CurrentValues.SetValues(entity);
            //return Task.CompletedTask;

            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                // var res= await dbConnection.QueryAsync(sql, entity);
                var res = await dbConnection.ExecuteScalarAsync(sql, entity);
                return (int)res;
            }
        }

        //Dispose
        #region Dispose
        private bool disposed;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //dispose managed resources
                    Connection.Dispose();
                }
            }
            //dispose unmanaged resources
            disposed = true;
        }
        #endregion
    }
}
