﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Repositories
{
    public class DropdownsRepositoryAsync : IDropdownsRepositoryAsync
    {
        private readonly IGenericRepositoryIListAsync _repository;
        public DropdownsRepositoryAsync( IGenericRepositoryIListAsync repositoryAsync)
        {
            _repository = repositoryAsync;
        }

        public async Task<IList> GetDepartments()
        {
            string query = string.Format(@"select * from public.fungetdepartment4ddl()");
            return await _repository.GetAsync(query);
        }
    }
}
