﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly IDistributedCache _distributedCache;
        private readonly IGenericRepositoryAsync<UserModel> _repository;
        public AuthRepository(IDistributedCache distributedCache, IGenericRepositoryAsync<UserModel> repositoryAsync)
        {
            _distributedCache = distributedCache;
            _repository = repositoryAsync;
        }
        public async Task<UserModel> GetLoginUser(string username, string password)
        {
            string query = "select * from public.fungetUserloginDetails('" + username + "','" + password + "')";
            return await _repository.GetAsync(query);
        }
    }
}
