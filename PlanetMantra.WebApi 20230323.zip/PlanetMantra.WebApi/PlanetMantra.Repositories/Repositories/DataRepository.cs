﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.Repositories
{
    public class DataRepository : IDataRepository
    {
        private readonly IRepositoryAsync<GetAllCustomersResponse> _repository;
        private readonly IDistributedCache _distributedCache;
        public DataRepository(IDistributedCache distributedCache, IRepositoryAsync<GetAllCustomersResponse> repository)
        {
            _distributedCache = distributedCache;
            _repository = repository;
        }
        public async Task<List<GetAllCustomersResponse>> GetAllAsync(int pageNumber, int pageSize)
        {
            string query = string.Format("select *,Count(*) Over () AS TotalCount from  customer order by id OFFSET({0} - 1) * {1} FETCH NEXT {1} ROWS ONLY; ", pageNumber, pageSize);
            var result = await _repository.GetAllAsync(query);

            return result;
        }
        public async Task<IList> GetPagedReponseAsync(int pageNumber, int pageSize)
        {
            string query = string.Format("select *,Count(*) Over () AS TotalCount from  customer order by id OFFSET({0} - 1) * {1} FETCH NEXT {1} ROWS ONLY; ", pageNumber, pageSize);
            var result = await _repository.GetPagedReponseAsync(query);

            return result;
        }
    }
}
