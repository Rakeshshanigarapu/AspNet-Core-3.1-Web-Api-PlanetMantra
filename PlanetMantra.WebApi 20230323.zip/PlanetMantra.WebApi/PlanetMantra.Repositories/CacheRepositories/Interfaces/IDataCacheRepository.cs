﻿using PlanetMantra.Domain.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.CacheRepositories.Interfaces
{
    public interface IDataCacheRepository
    {
        Task<List<GetAllCustomersResponse>> GetCachedListAsync(int pageNumber, int pageSize);
        Task<IList> GetPagedReponseCachedListAsync(int pageNumber, int pageSize);
        Task<IList> GetPagedReponseCachedListAsync(int pageNumber, int pageSize, string searchText, string sort);
    }
}
