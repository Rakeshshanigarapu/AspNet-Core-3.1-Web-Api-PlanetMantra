﻿using PlanetMantra.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.CacheRepositories.Interfaces
{
    public interface ICustomerCacheRepository
    {
        Task<List<Customer>> GetCachedListAsync(int pageNumber,int pageSize);
        Task<List<Customer>> GetCachedListAsync();

        Task<Customer> GetByIdAsync(int customerId);
    }
}
