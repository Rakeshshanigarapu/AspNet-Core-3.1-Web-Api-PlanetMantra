﻿using PlanetMantra.Domain.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.CacheRepositories.Interfaces
{
    public interface ICacheRepositoryAsync<T> where T : class
    {
        Task<T> GetByIdAsync(int id);
        Task<List<T>> GetAllAsync();
        Task<List<T>> GetAllAsync(int pageNumber, int pageSize);
        Task<List<T>> GetAllAsync(int pageNumber, int pageSize, string searchText, string sort);
    }
    public interface ICacheListRepositoryAsync
    {
        Task<Tuple<IList, string>> GetListByIdAsync(int id);
        Task<Tuple<IList, string>> GetAllListAsync();
        Task<Tuple<IList, string>> GetAllListAsync(int pageNumber, int pageSize);
        Task<Tuple<IList, string>> GetAllListAsync(int pageNumber, int pageSize, string searchText, string sort);
    }
}
