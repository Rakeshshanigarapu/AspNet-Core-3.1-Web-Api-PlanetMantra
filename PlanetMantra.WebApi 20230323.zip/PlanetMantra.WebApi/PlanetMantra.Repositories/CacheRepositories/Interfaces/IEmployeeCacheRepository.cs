﻿using System;
using System.Collections;
using System.Threading.Tasks;

namespace PlanetMantra.Repository.CacheRepositories.Interfaces
{
    public interface IEmployeeCacheRepository
    {
        Task<Tuple<IList, string>> GetListByIdAsync(int id);
        Task<Tuple<IList, string>> GetAllListAsync(int pageNumber, int pageSize,string searchText);
    }
}
