﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.CacheKeys;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AspNetCoreHero.Extensions.Caching;
using PlanetMantra.Infrastructure.Shared.Extensions;
using System.Linq;
using System.Collections;

namespace PlanetMantra.Repository.CacheRepositories.Repositories
{
    public class DataCacheRepository : IDataCacheRepository
    {
        private readonly IDistributedCache _distributedCache;
        private readonly IDataRepository _dataRepository;

        public DataCacheRepository(IDistributedCache distributedCache,IDataRepository dataRepository)
        {
            _distributedCache = distributedCache;
            _dataRepository = dataRepository;
        }

        public async Task<List<GetAllCustomersResponse>> GetCachedListAsync(int pageNumber, int pageSize)
        {
            string cacheKey = DataCacheKeys.GetPagedListKey(pageNumber, pageSize);
            var customerList = await _distributedCache.GetAsync<List<GetAllCustomersResponse>>(cacheKey);
            if (customerList == null)
            {
                customerList = await _dataRepository.GetAllAsync(pageNumber, pageSize);
                await _distributedCache.SetAsync(cacheKey, customerList);
            }
            return customerList;
        }
        public async Task<IList> GetPagedReponseCachedListAsync(int pageNumber, int pageSize)
        {
            string cacheKey = DataCacheKeys.GetPagedListKey(pageNumber, pageSize);
            var customerList = await _distributedCache.GetAsync<IList>(cacheKey);
            if (customerList == null)
            {
                customerList = await _dataRepository.GetAllAsync(pageNumber, pageSize);
                await _distributedCache.SetAsync(cacheKey, customerList);
            }
            return customerList;
        }

        public Task<IList> GetPagedReponseCachedListAsync(int pageNumber, int pageSize, string searchText, string sort)
        {
            throw new NotImplementedException();
        }
    }
}
