﻿using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using PlanetMantra.Domain.Entities;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Repository.Interfaces;
using PlanetMantra.LoggerService.Repositories;
using PlanetMantra.Domain.CacheKeys;
using System.Text.Json;
using System.Collections;
using PlanetMantra.Infrastructure.Shared;

namespace PlanetMantra.Repository.CacheRepositories.Repositories
{
    public class UserCacheRepository : ICacheRepositoryAsync<Users>
    {
        private readonly IDistributedCache _distributedCache;
        private readonly IUserRepository _userRepository;

        // private ILoggerService _loggerInstance;
        // protected ILoggerService _logger => _loggerInstance ??= HttpContext.RequestServices.GetService<ILoggerService>();
        private readonly ILoggerService _logger;
        public UserCacheRepository(IDistributedCache distributedCache, IUserRepository userRepository, ILoggerService loggerService)
        {
            _distributedCache = distributedCache;
            _userRepository = userRepository;
            _logger = loggerService;
        }
        public async Task<List<Users>> GetAllAsync()
        {
            string cacheKey = UserCacheKeys.ListKey;
            //Find cached item
            byte[] objectFromCache = await _distributedCache.GetAsync(cacheKey);
            if (objectFromCache != null)
            {
                //Deserialize it
                var jsonToDeserialize = System.Text.Encoding.UTF8.GetString(objectFromCache);
                var cacheResult = JsonSerializer.Deserialize<List<Users>>(jsonToDeserialize);
                if (cacheResult != null)
                {
                    _logger.LogInfo("load UserCacheRepository-GetAllAsync cache data.");
                    //If found, then return it
                    return cacheResult;
                }
            }

            _logger.LogInfo("load UserCacheRepository-GetAllAsync data from database.");
            //If not found, then recalculate response
            var result = _userRepository.GetAllAsync().Result;

            //Serialize the response
            byte[] objectToCache = JsonSerializer.SerializeToUtf8Bytes(result);
            var cacheEntryOptions = new DistributedCacheEntryOptions()
                .SetSlidingExpiration(TimeSpan.FromSeconds(60))
                .SetAbsoluteExpiration(TimeSpan.FromSeconds(180));

            //cache it
            await _distributedCache.SetAsync(cacheKey, objectToCache, cacheEntryOptions);
            return result;
        }

        public Task<List<Users>> GetAllAsync(int pageNumber, int pageSize)
        {
            throw new NotImplementedException();
        }

        public async Task<Users> GetByIdAsync(int id)
        {
            string cacheKey = UserCacheKeys.GetKey(id);
            //Find cached item
            byte[] objectFromCache = await _distributedCache.GetAsync(cacheKey);
            if (objectFromCache != null)
            {
                //Deserialize it
                var jsonToDeserialize = System.Text.Encoding.UTF8.GetString(objectFromCache);
                var cacheResult = JsonSerializer.Deserialize<Users>(jsonToDeserialize);
                if (cacheResult != null)
                {
                    _logger.LogInfo("load UserCacheRepository-GetByIdAsync cache data.");
                    //If found, then return it
                    return cacheResult;
                }
            }

            _logger.LogInfo("load UserCacheRepository-GetByIdAsync data from database.");
            //If not found, then recalculate response
            var result = _userRepository.GetByIdAsync(id).Result;
            if (result != null)
            {
                //Serialize the response
                byte[] objectToCache = JsonSerializer.SerializeToUtf8Bytes(result);
                var cacheEntryOptions = new DistributedCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromSeconds(10))
                    .SetAbsoluteExpiration(TimeSpan.FromSeconds(60));

                //cache it
                await _distributedCache.SetAsync(cacheKey, objectToCache, cacheEntryOptions);
            }
            return result;
        }
        
        public async Task<Tuple<IList,string>> GetAllAsync2(int pageNumber, int pageSize, string searchText, string sort)
        {
            string cacheKey = UserCacheKeys.GetPagedListKey(pageNumber, pageSize, searchText, sort);
            //Find cached item
            byte[] objectFromCache = await _distributedCache.GetAsync(cacheKey);
            if (objectFromCache != null)
            {
                //Deserialize it
                var jsonToDeserialize = System.Text.Encoding.UTF8.GetString(objectFromCache);
                var cacheResult = JsonSerializer.Deserialize<IList>(jsonToDeserialize);
                if (cacheResult != null)
                {
                    _logger.LogInfo("load UserCacheRepository-GetAllAsync cache data.");
                    //If found, then return it
                    return new Tuple<IList, string>(cacheResult,"Data from cache.");
                }
            }

            _logger.LogInfo("load UserCacheRepository-GetAllAsync data from database.");
            //If not found, then recalculate response
            //  var result = _userRepository.GetAllAsync(pageNumber,pageSize).Result;
            var result = _userRepository.GetUserPagedReponseAsync(pageNumber, pageSize,searchText,sort).Result;
            if (result != null)
            {
                //Serialize the response
                byte[] objectToCache = JsonSerializer.SerializeToUtf8Bytes(result);
                var cacheEntryOptions = new DistributedCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromSeconds(60))
                    .SetAbsoluteExpiration(TimeSpan.FromSeconds(180));

                //cache it
                await _distributedCache.SetAsync(cacheKey, objectToCache, cacheEntryOptions);
            }
            return new Tuple<IList, string>(result, "Data from database."); 
        }
       
        public async Task<Tuple<IList, string>> GetAllAsync(int pageNumber, int pageSize, string searchText, string sort)
        {
            string cacheKey = UserCacheKeys.GetPagedListKey(pageNumber, pageSize, searchText, sort);
            var cacheResult = _distributedCache.GetAsync<IList>(cacheKey).Result;
            if (cacheResult != null)
            {
                return new Tuple<IList, string>(cacheResult, "Data from cache.");
            }
            var result = _userRepository.GetUserPagedReponseAsync(pageNumber, pageSize, searchText, sort).Result;
          //  var result = _userRepository.GetAllAsyncList(pageNumber, pageSize, searchText, sort).Result;
            if (result != null)
            {
                await _distributedCache.SetAsync<IList>(cacheKey, result);
            }
            return new Tuple<IList, string>(result, "Data from database.");
        }

        public async Task<Tuple<IList, string>> GetAllAsyncList()
        {
            string cacheKey = UserCacheKeys.ListKey;
            var cacheResult = _distributedCache.GetAsync<IList>(cacheKey).Result;
            if (cacheResult != null)
            {
                return new Tuple<IList, string>(cacheResult, "Data from cache.");
            }
            var result = _userRepository.GetAllAsyncList().Result;
            if (result != null)
            {
                await _distributedCache.SetAsync<IList>(cacheKey, result);
            }
            return new Tuple<IList, string>(result, "Data from database.");
        }

    }
}
