﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.CacheKeys;
using PlanetMantra.LoggerService.Repositories;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using System.Threading.Tasks;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using PlanetMantra.Domain.Entities;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Repository.Interfaces;
using PlanetMantra.LoggerService.Repositories;
using PlanetMantra.Domain.CacheKeys;
using System.Text.Json;
using System.Collections;
using PlanetMantra.Infrastructure.Shared;

namespace PlanetMantra.Repository.CacheRepositories.Repositories
{
    public class EmployeeCacheRepository : IEmployeeCacheRepository
    {
        private readonly IDistributedCache _distributedCache;
        private readonly IEmployeeRepositoryAsync _empRepository;

        private readonly ILoggerService _logger;
        public EmployeeCacheRepository(IDistributedCache distributedCache, ILoggerService loggerService, IEmployeeRepositoryAsync empRepository)
        {
            _distributedCache = distributedCache;
            _empRepository = empRepository;
            _logger = loggerService;
        }
        
        public async Task<Tuple<IList, string>> GetAllListAsync(int pageNumber, int pageSize, string searchText)
        {
            string cacheKey = EmployeeCacheKeys.GetPagedListKey(pageNumber, pageSize,searchText);
            //Find cached item
            byte[] objectFromCache = await _distributedCache.GetAsync(cacheKey);
            if (objectFromCache != null)
            {
                //Deserialize it
                var jsonToDeserialize = System.Text.Encoding.UTF8.GetString(objectFromCache);
                var cacheResult = JsonSerializer.Deserialize<IList>(jsonToDeserialize);
                if (cacheResult != null)
                {
                    _logger.LogInfo("load EmployeeCacheRepository-GetAllListAsync cache data.");
                    //If found, then return it
                    return new Tuple<IList, string>(cacheResult, "Data from cache.");
                }
            }

            _logger.LogInfo("load EmployeeCacheRepository-GetAllListAsync data from database.");
            //If not found, then recalculate response
            var result = _empRepository.GetAllEmployees(pageNumber, pageSize,searchText).Result;
            if (result != null)
            {
                //Serialize the response
                byte[] objectToCache = JsonSerializer.SerializeToUtf8Bytes(result);
                var cacheEntryOptions = new DistributedCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromMinutes(5))
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(10));

                //cache it
                await _distributedCache.SetAsync(cacheKey, objectToCache, cacheEntryOptions);
            }
            return new Tuple<IList, string>(result, "Data from database.");
        }
        
        /*
        public async Task<Tuple<IList, string>> GetAllListAsync(int pageNumber, int pageSize, string searchText)
        {
            string cacheKey = EmployeeCacheKeys.GetPagedListKey(pageNumber, pageSize, searchText);
            var cacheResult = _distributedCache.GetAsync<IList>(cacheKey).Result;
            if (cacheResult != null)
            {
                _logger.LogInfo("load EmployeeCacheRepository-GetAllListAsync cache data.");
                return new Tuple<IList, string>(cacheResult, "Data from cache.");
            }
            _logger.LogInfo("load EmployeeCacheRepository-GetAllListAsync data from database.");
            var result = _empRepository.GetAllEmployees(pageNumber, pageSize, searchText).Result;
            if (result != null)
            { 
                await _distributedCache.SetAsync<IList>(cacheKey, result);
            }
            return new Tuple<IList, string>(result, "Data from database.");
        }
        */

        public Task<Tuple<IList, string>> GetListByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public class Emp
        {
            public Guid emp_guid { get; set; }
            public int emp_no { get; set; }
            public string f_name { get; set; }
            public string l_name { get; set; }
            public string mobile_no { get; set; }
            public string work_email { get; set; }
            public string job_title { get; set; }
            public string employment_status_name { get; set; }
            public int status { get; set; }
            public long TotalCount;
        }
    }
}
