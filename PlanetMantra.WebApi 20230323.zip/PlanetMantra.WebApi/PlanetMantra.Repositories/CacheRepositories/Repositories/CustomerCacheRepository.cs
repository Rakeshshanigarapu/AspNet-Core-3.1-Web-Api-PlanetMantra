﻿using Microsoft.Extensions.Caching.Distributed;
using PlanetMantra.Domain.CacheKeys;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AspNetCoreHero.Extensions.Caching;
using PlanetMantra.Infrastructure.Shared.Extensions;
using System.Linq;

namespace PlanetMantra.Repository.CacheRepositories.Repositories
{
    public class CustomerCacheRepository : ICustomerCacheRepository
    {
        private readonly IDistributedCache _distributedCache;
        private readonly ICustomerRepository _customerRepository;

        public CustomerCacheRepository(IDistributedCache distributedCache, ICustomerRepository customerRepository)
        {
            _distributedCache = distributedCache;
            _customerRepository = customerRepository;
        }

        public async Task<Customer> GetByIdAsync(int customerId)
        {
            string cacheKey = CustomerCacheKeys.GetKey(customerId);
            var customer = await _distributedCache.GetAsync<Customer>(cacheKey);
            if (customer == null)
            {
                customer = await _customerRepository.GetByIdAsync(customerId);
                if (customer != null)
                    await _distributedCache.SetAsync(cacheKey, customer);
            }
             

            return customer;
        }

        public async Task<List<Customer>> GetCachedListAsync()
        {
            string cacheKey = CustomerCacheKeys.ListKey;
            var customerList = await _distributedCache.GetAsync<List<Customer>>(cacheKey);
            if (customerList == null)
            {
                customerList = await _customerRepository.GetAllAsync();
                if (customerList != null)
                    await _distributedCache.SetAsync(cacheKey, customerList);
            }
            return customerList;
        }
        public async Task<List<Customer>> GetCachedListAsync(int pageNumber, int pageSize)
        {
            string cacheKey = CustomerCacheKeys.GetPagedListKey(pageNumber,pageSize);
            var customerList = await _distributedCache.GetAsync<List<Customer>>(cacheKey);
            if (customerList == null)
            {
                customerList = await _customerRepository.GetAllAsync(pageNumber,pageSize);
                if (customerList != null)
                    await _distributedCache.SetAsync(cacheKey, customerList);
            }
            return customerList;
        }
    }
}
