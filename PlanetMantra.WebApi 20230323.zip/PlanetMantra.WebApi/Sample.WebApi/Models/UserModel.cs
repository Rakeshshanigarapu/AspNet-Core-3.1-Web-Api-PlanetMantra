﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infinity.WebApi.Models
{
    public class UserModel
    { 
        public string User_Role { get; set; }
        public string User_UUID { get; set; }
        public string status { get; set; }
        public string Username { get; set; }
        public string F_Name { get; set; }
        public string M_Name { get; set; }
        public string L_Name { get; set; }
        public string Mobile_No { get; set; }
        public string Work_Email { get; set; }
        public string Job_Title { get; set; }
        public string Token { get; set; }
    }
    public class UserLogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
    //public class UserConstants
    //{
    //    public static List<UserModel> Users = new List<UserModel>()
    //    {
    //        new UserModel(){Username="admin",EmailAddress="admin@xyz.com",Password="ABC123abc",FirstName="Rocky_Admin",LastName="S",Role="Administrator" },
    //        new UserModel(){Username="seller",EmailAddress="seller@xyz.com",Password="ABC123abc",FirstName="Rocky_Seller",LastName="S",Role="SellerRole" }
    //    };
    //}
}
