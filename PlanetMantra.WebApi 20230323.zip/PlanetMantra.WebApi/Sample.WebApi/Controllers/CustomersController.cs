﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Handlers.Requests.Customers;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : BaseApiController<CustomersController>
    {
       // private readonly IGenericRepositoryAsync<Customer> customer;

        private readonly ICustomerCacheRepository cust; 

        //public CustomersController(IGenericRepositoryAsync<Customer> customer, ICustomerCacheRepository cust)
        public CustomersController(ICustomerCacheRepository cust)
        {
            //this.customer = customer;
            this.cust = cust;
        }
        [HttpGet("GetAllCustomers")]
        public IActionResult GetAllCustomers()
        {
            _logger.LogInfo("Fetching All GetAllCustomers"); 

            var customers = cust.GetCachedListAsync().Result; 

            _logger.LogInfo($"Total customer count: {customers.Count}");
            return Ok(customers);
        }  
    }
}
