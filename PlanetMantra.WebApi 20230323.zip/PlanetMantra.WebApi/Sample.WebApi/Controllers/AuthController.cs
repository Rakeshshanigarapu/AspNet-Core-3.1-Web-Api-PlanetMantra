﻿using Infinity.WebApi.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Infrastructure.Shared.Results;
using PlanetMantra.Repository.Interfaces;
using Sample.WebApi.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Infinity.WebApi.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IAuthRepository _authRepository;

        public AuthController(IConfiguration configuration,IAuthRepository authRepository)
        {
            _configuration = configuration;
            _authRepository = authRepository;
        }
        [AllowAnonymous]
        [HttpPost("Login")]
        public IActionResult Login([FromBody] UserLogin userLogin)
        {
            var user = Authenticate(userLogin);
            if (user != null)
            {
                var token = Generate(user);
                user.Token = token;
                //return Ok(token);
                return Ok(Result<UserModel>.Success(user));
            }
            //return NotFound("User not found");
            return Ok(Result.Fail("Invalid Username/Password"));

        }
        //[ApiExplorerSettings(IgnoreApi = true)]
        //[AllowAnonymous]
        //[HttpPost("GetUser")]
        //public IActionResult LoginUser()
        //{
        //    var user = _authRepository.GetUser().Result;
        //    if (user != null&&user.Count>0)
        //    { 
        //        return Ok(Result<IList>.Success(user));
        //    } 
        //    return Ok(Result.Fail());

        //}

        private string Generate(UserModel user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
            new Claim(ClaimTypes.NameIdentifier,user.Username),
            new Claim(ClaimTypes.Email,user.Work_Email),
            new Claim(ClaimTypes.GivenName,user.F_Name),
            new Claim(ClaimTypes.Surname,user.L_Name),
            new Claim(ClaimTypes.Role,user.User_Role)
            };

            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(120),
                signingCredentials: credentials
                );

            return new JwtSecurityTokenHandler().WriteToken(token);         
        }

        private UserModel Authenticate(UserLogin userLogin)
        {
            //var currentUser = UserConstants.Users.FirstOrDefault(o => o.Username.ToLower() ==
            // userLogin.Username.ToLower() && o.Password == userLogin.Password);
            var EncryptedPassword = userLogin.Password;// Cryptography.Encrypt(userLogin.Password);
              var currentUser = _authRepository.GetLoginUser(userLogin.Username.ToLower(), EncryptedPassword).Result;
            if (currentUser != null)
            {   
                return currentUser;
            }

            return null;
        }
    }
}
