﻿
using PlanetMantra.LoggerService.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sample.WebApi.CustomDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseOrderController : BaseApiController<PurchaseOrderController>//ControllerBase
    {
        /*
        private ILoggerService _logger;
        public PurchaseOrderController(ILoggerService logger)
        {
            _logger = logger;
        }
        */

        [HttpGet("GetPurchaseOrder")]
        public IActionResult GetPurchaseOrder()
        {
            _logger.LogInfo("Fetching All Purchase orders");
            // Get Purchase data from  PurchaseOrder DB
            var purchaseOrders = PurchaseOrderDB.GetPurchaseOrders();

            // Uncomment below two lines code to get exception.
            //var num1 = 100;
            //dynamic num = num1 / 0; 

            _logger.LogInfo($"Total purchase order count: {purchaseOrders.Count}");
            return Ok(purchaseOrders);
        }
    }
}
