﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using PlanetMantra.Handlers.Requests.Customers;
using PlanetMantra.Infrastructure.Shared.Pagination.Filter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.WebApi.Controllers
{
    /// <summary>
    /// In this controller we are using in mediator
    /// </summary>
    public class CustDataPaginationController : ControllerBase
    {
        private readonly IMediator mediator;

        public CustDataPaginationController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        /// <summary>
        /// This data come from mediator
        /// </summary>
        /// <param name="filter">PageNumber,PageSize</param>
        /// <returns></returns>
        [HttpGet("GetAllCustomersPageWise")]
        public async Task<IActionResult> GetAllCustomersPageWise([FromQuery] PaginationFilter filter)
        { 
            var pagedData = await mediator.Send(new GetAllDataPagination(filter.PageNumber, filter.PageSize));
              return Ok(pagedData);
        }
        [HttpGet("GetPagedReponseCachedListAsync")]
        public async Task<IActionResult> GetPagedReponseCachedListAsync([FromQuery] PaginationFilter filter)
        {
            var pagedData = await mediator.Send(new GetAllDataPagination2(filter.PageNumber, filter.PageSize));
            return Ok(pagedData);
        }
    }
}
