﻿using AspNetCoreHero.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PlanetMantra.Infrastructure.Shared.DTOs.Mail;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using PlanetMantra.Infrastructure.Shared.Interface;
using PlanetMantra.Infrastructure.Shared.Services;
using PlanetMantra.LoggerService.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infinity.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IMailService _emailService; 
        private readonly ILoggerService _logger;
        public EmailController(IMailService emailService, ILoggerService logger)
        {
            _emailService = emailService; 
            _logger = logger;
        }
        [HttpPost]
        public async Task<Result<string>> SendEmail([FromForm] MailRequest request)
        {
          /*      await _emailService.SendAsync(new MailRequest() 
               { From = "ralesh@test.com",
                   To = request.To, 
                   Body = $"Please confirm your account by <a href='#'>clicking here</a>.", 
                   Subject = "Confirm Registration" 
               });
             */
            await _emailService.SendAsync(request);
            return Result<string>.Success("111", message: $"User Registered. Confirmation Mail has been delivered to your Mailbox. (DEV) Please confirm your account by visiting this URL #");             
        }
    }
}
