﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlanetMantra.LoggerService.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using MediatR;

namespace Infinity.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public abstract class BaseApiController<T> : ControllerBase
    { 
        private ILoggerService _loggerInstance; 
        protected ILoggerService _logger => _loggerInstance ??= HttpContext.RequestServices.GetService<ILoggerService>();

    }
}
