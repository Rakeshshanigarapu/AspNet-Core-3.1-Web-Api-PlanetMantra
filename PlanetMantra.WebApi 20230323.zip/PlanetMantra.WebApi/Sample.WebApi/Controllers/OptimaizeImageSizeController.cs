﻿using AspNetCoreHero.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlanetMantra.Infrastructure.Shared.Extensions;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks; 

namespace Infinity.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OptimaizeImageSizeController : BaseApiController<OptimaizeImageSizeController>
    { 

        [HttpPost("postOptimizeImage")]
        public Result<string> postOptimizeImage(IFormFile file, int maxWidth, int maxHeight)
        {
            if (file == null || file.Length == 0)
            {
                return Result<string>.Fail("bad request");
            }

            var image = file.OptimaizeImageSizeInByteArray(maxWidth, maxHeight);
            //image save in db code

            string strImg = Convert.ToBase64String(image);


            return Result<string>.Success("111", message: $"Image saved in DB side as a byte array, Base64String: " + strImg);
        }
        [HttpPost("postResizeImage")]
        public Result<string> postResizeImage(IFormFile file, int maxWidth, int maxHeight)
        {
            string fileName = string.Empty;
            string path = string.Empty;
            if (file == null || file.Length == 0)
            {
                return Result<string>.Fail("bad request");
            }
            fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
            path = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "images")); 
            string fullPath = Path.Combine(path, fileName);

            file.OptimaizeImageSizeInImage(maxWidth, maxHeight,fullPath); 

            return Result<string>.Success("111", message: $"Image saved in server side. "+ fullPath);
        }
        /*
        [HttpPost("postResizeImage2")]
        public IActionResult postResizeImage2(IFormFile file, int maxWidth, int maxHeight)
        {
            string fileName = string.Empty;
            string path = string.Empty;
            if (file.Length > 0)
            {
                fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
                var path2 = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "images"));
                path = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "images"));

                string fullPath = Path.Combine(path, fileName);
                using (var image = Image.Load(file.OpenReadStream()))
                {
                    string newSize = ResizeImage(image, maxWidth, maxHeight);
                    string[] aSize = newSize.Split(',');
                    image.Mutate(h => h.Resize(Convert.ToInt32(aSize[1]), Convert.ToInt32(aSize[0])));
                    image.Save(fullPath);
                }
            }
            return Ok("image saved..!");
        }

        private string ResizeImage(Image img, int maxWidth, int maxHeight)
        {
            if (img.Width > maxHeight || img.Height > maxHeight)
            {
                double widthRatio = (double)img.Width / (double)maxWidth;
                double heightRatio = (double)img.Height / (double)maxHeight;
                double ratio = Math.Max(widthRatio, heightRatio);
                int newwidth = (int)(img.Width / ratio);
                int newHeight = (int)(img.Height / ratio);
                return newHeight.ToString() + "," + newwidth.ToString();
            }
            else
            {
                return img.Height.ToString() + "," + img.Width.ToString();
            }
        }
        */
    }
}
