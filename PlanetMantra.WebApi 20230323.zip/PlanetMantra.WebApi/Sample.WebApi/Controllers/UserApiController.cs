﻿using AspNetCoreHero.Results;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Handlers.Requests.UserRequests;
using PlanetMantra.Infrastructure.Shared.Pagination.Filter;
using PlanetMantra.Repository.Interfaces;
using Sample.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Sample.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserApiController : BaseApiController<UserApiController>
    {
        private readonly IMediator mediator;
        private readonly  IUserRepository _userRepository;

        public UserApiController(IMediator mediator, IUserRepository userRepository)
        {
            this.mediator = mediator;
            this._userRepository = userRepository;
        }
        [HttpPost("AddUser")]
        public IActionResult AddUser([FromBody] Users user)
        {
            var res = mediator.Send(new AddUserAsync(user)).Result;
            return Ok(res);
        }
        [HttpPut("UpdateUser")]
        public IActionResult UpdateUser([FromBody] Users user)
        {
            var res = mediator.Send(new UpdateUserAsync(user)).Result;
            return Ok(res);
        }
        [HttpPatch("UpdateUser2")]
        public IActionResult UpdateUser2([FromBody] Users user)
        {
            var res = mediator.Send(new UpdateUserAsync(user)).Result;
            return Ok(res);
        }
        [HttpGet("GetUsers")]
        public IActionResult GetUsers()
        {
            var users = mediator.Send(new GetAllUsersCachedQuery()).Result;
            return Ok(users);
        }
        [HttpGet("GetUserById")]
        public IActionResult GetUser([FromQuery] int id)
        {
            var user = mediator.Send(new GetUserByIdCachedQuery(id)).Result;
            return Ok(user);
        }
        [HttpDelete("DeleteUser")]
        public IActionResult DeleteUser([FromQuery] int id)
        {
            var res = mediator.Send(new DeleteUserAsync(id)).Result;
            return Ok(res);
        }


        [HttpGet("Public")]
        public Result<string> Public()
        {
            // return Result<string>.Success("111","Hi, you're an public property");
            return Result<string>.Fail( "Hi, you're an public property");
        }
        [HttpGet("Admins")]
        [Authorize(Roles = "Administrator")]
        public IActionResult AdminsEndPoint()
        {
            var currentUser = GetCurrentUser();

            return Ok($"Hi {currentUser.Username}, you are on {currentUser.Role}");
        }
        [HttpGet("Seller")]
        [Authorize(Roles = "SellerRole")]
        public IActionResult SellersEndPoint()
        {
            var currentUser = GetCurrentUser();

            return Ok($"Hi {currentUser.Username}, you are on {currentUser.Role}");
        }

        [HttpGet("GetPagedReponseCachedListAsync")]
        public async Task<IActionResult> GetPagedReponseCachedListAsync([FromQuery] PaginationFilter filter,string searchText, string sort)
        {
            var pagedData = await mediator.Send(new GetUserByPagingCachedQuery(filter.PageNumber, filter.PageSize,searchText,sort));
            return Ok(pagedData);
        }

        private UserModel GetCurrentUser()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                var userClaims = identity.Claims;
                return new UserModel
                {
                    Username = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.NameIdentifier)?.Value,
                    EmailAddress = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Email)?.Value,
                    FirstName = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.GivenName)?.Value,
                    LastName = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Surname)?.Value,
                    Role = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Role)?.Value,
                };
            }
            return null;
                 
        }
        [HttpGet("GetUsersIList")]
        public IActionResult GetAllListUsers()
        {
           var user = mediator.Send(new GetUsersListCachedQuery()).Result;
            //var user = _userRepository.GetAllAsyncList();
            return Ok(user);
        }
    }
}
