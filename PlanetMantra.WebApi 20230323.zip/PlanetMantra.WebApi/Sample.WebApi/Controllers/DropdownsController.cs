﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PlanetMantra.Infrastructure.Shared.Results;
using PlanetMantra.Repository.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infinity.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class DropdownsController : BaseApiController<DropdownsController>
    {
        //private readonly IConfiguration _configuration;
        private readonly IDropdownsRepositoryAsync _dropRepository;
        public DropdownsController(IConfiguration configuration, IDropdownsRepositoryAsync dropRepository)
        {
           // _configuration = configuration;
            _dropRepository = dropRepository;
        }
        [HttpGet("Department")]
        public IActionResult Department()
        {
            var result = _dropRepository.GetDepartments().Result;
            if (result != null)
            {
                return Ok(Result<IList>.Success(result));
            }
            return Ok(Result.Fail("No data found"));

        }
    }
}
