﻿using AspNetCoreHero.Results;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Handlers.Requests.Customers;
using PlanetMantra.Infrastructure.Shared.Pagination.Filter;
using PlanetMantra.Infrastructure.Shared.Pagination.Helpers;
using PlanetMantra.Infrastructure.Shared.Pagination.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Sample.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustMediatorController : ControllerBase
    {
        private readonly IMediator mediator; 

        public CustMediatorController(IMediator mediator )
        { 
            this.mediator = mediator; 
        }
        //its(GetUserRequest) local class
        [HttpGet("GetCustomers")]
        public IActionResult GetCustomers()
        {  
            var customers = mediator.Send(new GetUserRequest()).Result; 
            return Ok(customers);
        }
        //its(GetUserRequestCachedQuery) classlibrary class 
        [HttpGet("GetUser")]
        public IActionResult GetCustomer()
        { 
            var customers = mediator.Send(new GetUserRequestCachedQuery()).Result;
            return Ok(customers);
        }
        [HttpGet("GetCustomerById")]
        public IActionResult GetCustomerById(int id)
        {
            var customers = mediator.Send(new GetCustomerRequest() { CustomerId=id}).Result;
            if (customers != null)
                 return Ok(customers); 
            else
            {
                 return Ok("No data found."); 
            }
        }
        [HttpGet("GetALLCustomers")]
        public IActionResult GetALLCustomers()
        {
            try
            {

                var customers = mediator.Send(new GetAllCustomersCachedQuery()).Result;
                if (customers != null)
                    return Ok(customers);
                else
                {
                    return Ok("No data found.");
                }

            }
            catch (Exception ex)
            {
                return Ok(ex.Message);
            }
        }
        [HttpGet("GetAllCustomersPageWise")]
        public async Task<IActionResult> GetAllCustomersPageWise([FromQuery] PaginationFilter filter)
        {
           // var route = Request.Path.Value;
           // var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize);

            var pagedData = await mediator.Send(new GetAllCustomersPagination(filter.PageNumber, filter.PageSize));
            //var totalRecords = pagedData.Data.Select(m=>m.TotalCount).FirstOrDefault();
            //var pagedReponse = PaginationHelper.CreatePagedResponse<Customer>(pagedData, validFilter, totalRecords, uriService, route);
            return Ok(pagedData);
        }
    }

    public class GetUserRequest : IRequest<Result<string>>
    {
        public class GetUserRequestHandler : IRequestHandler<GetUserRequest, Result<string>>
        {
            public async Task<Result<string>> Handle(GetUserRequest request, CancellationToken cancellationToken)
            {
                var result = "Rocky";
                // await Task.CompletedTask;
                //return Result<string>.Success(result);
               return await Result<string>.SuccessAsync(result);
            }
        }
    }
}
