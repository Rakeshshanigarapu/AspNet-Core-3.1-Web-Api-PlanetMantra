﻿using Infinity.WebApi.Security;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Handlers.Requests.Employee;
using PlanetMantra.Infrastructure.Shared.Pagination.Filter;
using PlanetMantra.Infrastructure.Shared.Results;
using PlanetMantra.Repository.Interfaces;
using Sample.WebApi.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Infinity.WebApi.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
   // [Authorize]
    public class EmployeeController : ControllerBase
    {
        //private readonly IConfiguration _configuration;
        private readonly IEmployeeRepositoryAsync _empRepository;
        private readonly IMediator _mediator;

        public EmployeeController(IConfiguration configuration, IMediator mediator, IEmployeeRepositoryAsync empRepository)
        {
            //_configuration = configuration;
           _empRepository = empRepository;
            _mediator = mediator;
        }
        [HttpGet("GetNewEmployeeNumber")]
        public async Task<IActionResult> GetNewEmployeeNumber()
        { 
            var result =await _empRepository.GetNewEmployeeNumber();
            if (result != null)
            {
                return Ok(Result<IList>.Success(result));
            }
            return Ok(Result.Fail("No data found"));
        }
        [HttpGet("IsValidUserName")]
        public async Task<IActionResult> IsValidUserName(string userName)
        {
            var result = await _empRepository.IsValidUserName(userName);
            if (result != null)
            {
                return Ok(Result<IList>.Success(result));
            }
            return Ok(Result.Fail("No data found"));
        }
        [HttpGet("IsValidEmplyeeNumber")]
        public async Task<IActionResult> IsValidEmplyeeNumber(int emplyeeNumber)
        {
            var result = await _empRepository.IsValidEmployeeNumber(emplyeeNumber);
            if (result != null)
            {
                return Ok(Result<IList>.Success(result));
            }
            return Ok(Result.Fail("No data found"));
        }

        [HttpGet("GetAllEmployees")]
        public async Task<IActionResult> GetAllEmployeesAsync([FromQuery] PaginationFilter filter)
        {
            var pagedData = await _mediator.Send(new GetAllEmployeesByPagingCachedQuery(filter.PageNumber, filter.PageSize,filter.SearchText.Replace(":","=")));
            return Ok(pagedData);
        }
        [HttpPost("AddEmployee")]
        public async Task<IActionResult> AddEmployeeAsync([FromForm]AddEmployeeModel model)
        {
            /*  var result = await _empRepository.AddEmployeeAsync(model);
              if (result != null)
              {
                  return Ok(Result<IList>.Success(result));
              }
              */
            var res = model;
            await Task.CompletedTask;
            return Ok(Result.Fail("No data found"));
        }
    }
}
