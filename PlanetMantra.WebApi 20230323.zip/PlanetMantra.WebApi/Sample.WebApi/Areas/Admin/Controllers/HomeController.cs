﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.WebApi.Areas.Admin.Controllers
{
    [Route("api/admin/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        [HttpGet("Get")]
        public IActionResult GetPurchaseOrder()
        { 
            return Ok("It's Areas Admin Home Controller");
        }
        [HttpGet("Get2")]
        public IActionResult GetPurchaseOrder2()
        {
            return Ok("It's Areas Admin Home Controller2");
        }
    }
}
