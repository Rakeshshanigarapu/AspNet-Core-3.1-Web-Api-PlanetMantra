﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using System.Reflection;
//using PlanetMantra.Repository.CacheRepositories.Interfaces;
//using PlanetMantra.Domain.Entities;
//using PlanetMantra.Repository.CacheRepositories.Repositories;
using PlanetMantra.Repository.Repositories;
using PlanetMantra.Repository.Interfaces;
//using PlanetMantra.Handlers.Requests.UserRequests;
using PlanetMantra.LoggerService.Repositories;
using PlanetMantra.Infrastructure.Shared.Interface;
using PlanetMantra.Infrastructure.Shared.Services;
using PlanetMantra.Handlers.Requests.Employee;
using PlanetMantra.Repository.CacheRepositories.Interfaces;
using PlanetMantra.Repository.CacheRepositories.Repositories;
//using PlanetMantra.Handlers.Requests.Customers;

namespace Sample.WebApi.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddSharedInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            // //returns the assembly where the current code is being executed
            services.AddMediatR(Assembly.GetExecutingAssembly());
            //this assembly from a class located in the class library containing the queries
            //services.AddMediatR(typeof(GetUserRequestCachedQuery).Assembly);
            //services.AddMediatR(typeof(GetCustomerRequest).Assembly);
            //services.AddMediatR(typeof(GetAllCustomersCachedQuery).Assembly);
            //services.AddMediatR(typeof(GetAllCustomersPagination).Assembly);


            services.AddDistributedMemoryCache(); // Add distributed memory cache dependencies 

            services.Configure<MailSettings>(configuration.GetSection("MailSettings"));
            services.Configure<ConnectionStrings>(configuration.GetSection("ConnectionStrings"));


            //configure logger service
            services.AddSingleton<ILoggerService, LoggerRepository>();
            //configure Email service
            services.AddTransient<IMailService, SMTPMailService>();
            //services.AddTransient(typeof(IRepositoryAsync<>), typeof(RepositoryAsync<>));
            //services.AddSingleton<ICustomerRepository, CustomerRepository>();
            //services.AddSingleton<ICustomerCacheRepository, CustomerCacheRepository>();
            ////services.AddSingleton<IUriService, UriService>();

            //services.AddSingleton<IDataRepository, DataRepository>();
            //services.AddSingleton<IDataCacheRepository, DataCacheRepository>(); 

            services.AddSingleton<IAuthRepository, AuthRepository>();
            services.AddTransient(typeof(IGenericRepositoryAsync<>), typeof(GenericRepositoryAsync<>));
            services.AddSingleton<IGenericRepositoryIListAsync, GenericRepositoryIListAsync>();

            services.AddSingleton<IEmployeeRepositoryAsync, EmployeeRepositoryAsync>();
            services.AddSingleton<IEmployeeCacheRepository, EmployeeCacheRepository>();

            services.AddSingleton<IDropdownsRepositoryAsync, DropdownsRepositoryAsync>();



            //services.AddSingleton<ICacheRepositoryAsync<Users>, UserCacheRepository>();
            //services.AddSingleton<IUserRepository, UserRepository>();
            //services.AddMediatR(typeof(GetAllUsersCachedQuery).Assembly);
            //services.AddMediatR(typeof(GetUserByIdCachedQuery).Assembly);
            services.AddMediatR(typeof(GetAllEmployeesByPagingCachedQuery).Assembly);
        }
    }
}
