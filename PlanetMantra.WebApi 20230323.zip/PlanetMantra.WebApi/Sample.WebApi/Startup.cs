
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog;
using PlanetMantra.Domain.Entities;
using PlanetMantra.Infrastructure.Shared.DTOs.Settings;
using PlanetMantra.Infrastructure.Shared.Interface;
using PlanetMantra.Infrastructure.Shared.Services;
using PlanetMantra.LoggerService.Repositories;
//using PlanetMantra.Repository.CacheRepositories.Interfaces;
//using PlanetMantra.Repository.CacheRepositories.Repositories;
using PlanetMantra.Repository.Interfaces;
using PlanetMantra.Repository.Repositories;
using Sample.WebApi.Middlewares;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;
using MediatR;
//using PlanetMantra.Handlers.Requests.Customers;
//using PlanetMantra.Infrastructure.Shared.Pagination.Services;
//using PlanetMantra.Handlers.Requests.UserRequests;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerUI;

namespace Sample.WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            //  LogManager.LoadConfiguration(string.Concat(Directory.GetCurrentDirectory(),"/nlog.config"));
            LogManager.LoadConfiguration(Environment.CurrentDirectory + Path.DirectorySeparatorChar + "nlog.config");
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(typeof(Startup));

            //Add JwtBearer
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = Configuration["Jwt:Issuer"],
                        ValidAudience = Configuration["Jwt:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                    };
                });

            services.AddMvc();
            services.AddControllers();
            services.AddRazorPages();


            //// //returns the assembly where the current code is being executed
            //services.AddMediatR(Assembly.GetExecutingAssembly());
            ////this assembly from a class located in the class library containing the queries
            //services.AddMediatR(typeof(GetUserRequestCachedQuery).Assembly);
            //services.AddMediatR(typeof(GetCustomerRequest).Assembly);
            //services.AddMediatR(typeof(GetAllCustomersCachedQuery).Assembly);
            //services.AddMediatR(typeof(GetAllCustomersPagination).Assembly);


            //services.AddDistributedMemoryCache(); // Add distributed memory cache dependencies 

            //services.Configure<MailSettings>(Configuration.GetSection("MailSettings"));
            //services.Configure<ConnectionStrings>(Configuration.GetSection("ConnectionStrings"));


            //Enable CORS
            services.AddCors(c => {
                c.AddPolicy("AllowOrigin", options => options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });

            ////configure logger service
            //services.AddSingleton<ILoggerService, LoggerRepository>();
            ////configure Email service
            //services.AddTransient<IMailService, SMTPMailService>();
            //services.AddTransient(typeof(IRepositoryAsync<>), typeof(RepositoryAsync<>));
            //services.AddSingleton<ICustomerRepository, CustomerRepository>();
            //services.AddSingleton<ICustomerCacheRepository, CustomerCacheRepository > ();
            ////services.AddSingleton<IUriService, UriService>();

            //services.AddSingleton<IDataRepository, DataRepository>();
            //services.AddSingleton<IDataCacheRepository, DataCacheRepository>();

            //services.AddSingleton<ICacheRepositoryAsync<Users>, UserCacheRepository>();
            //services.AddSingleton<IUserRepository, UserRepository>();
            //services.AddMediatR(typeof(GetAllUsersCachedQuery).Assembly);
            //services.AddMediatR(typeof(GetUserByIdCachedQuery).Assembly);

            Sample.WebApi.Extensions.ServiceCollectionExtensions.AddSharedInfrastructure(services, Configuration);

            services.AddControllers();
            /*
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Planetmantra Service API",
                    Version = "v2",
                    Description = "Sample service for Learner",
                }); 
            });
            */
            services.AddSwaggerGen(s =>
            {
                s.SwaggerDoc("v2", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Planetmantra Service API",
                    Description = "Sample service for Learner",
                    //Contact = new OpenApiContact
                    //{
                    //    Name = "R O C K Y",
                    //    Email = "rakesh.shanigarapu@gmail.com",
                    //    Url = new Uri("https://www.linkedin.com/in/ignaciojv/")
                    //},
                    //License = new OpenApiLicense
                    //{
                    //    Name = "Testing",
                    //    Url = new Uri("https://github.com/ignaciojvig/ChatAPI/blob/master/LICENSE")
                    //}

                });

                s.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme (Example: 'Bearer 12345abcdef')",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                s.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                        }
                    },
                    Array.Empty<string>()
                }
            });

            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //Enable CORS
            app.UseCors(options => options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //Configure Exception Middelware
            app.UseMiddleware<ExceptionMiddleware>();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(options => {
                options.SwaggerEndpoint("/swagger/v2/swagger.json", "Planetmantra Services");
                options.DocExpansion(DocExpansion.None);
                });
        }
    }
}
