﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.CacheKeys
{
    public class CustomerCacheKeys
    {
        public static string ListKey => "CustomerList";

        public static string SelectListKey => "CustomerSelectList";

        public static string GetKey(int customerId) => $"Customer-{customerId}";

        public static string GetDetailsKey(int customerId) => $"CustomerDetails-{customerId}";

        public static string GetPagedListKey(int pageNumber, int pageSize) => $"CustomerList-{pageNumber}-{pageSize}";
    }
}
