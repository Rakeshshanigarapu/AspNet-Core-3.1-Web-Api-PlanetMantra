﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.CacheKeys
{
    public class UserCacheKeys
    {
        public static string ListKey => "UserList";

        public static string SelectListKey => "UserSelectList";

        public static string GetKey(int customerId) => $"User-{customerId}";

        public static string GetDetailsKey(int customerId) => $"UserDetails-{customerId}";

        public static string GetPagedListKey(int pageNumber, int pageSize) => $"UserList-{pageNumber}-{pageSize}";

        public static string GetPagedListKey(int pageNumber, int pageSize, string searchText, string sort) => $"UserList-{pageNumber}-{pageSize}-{searchText}-{sort}";
    }
}
