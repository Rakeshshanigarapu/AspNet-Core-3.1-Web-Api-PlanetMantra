﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.CacheKeys
{ 
    public class DataCacheKeys
    {
        public static string ListKey => "DataList";

        public static string SelectListKey => "DataSelectList";

        public static string GetKey(int customerId) => $"Data-{customerId}";

        public static string GetDetailsKey(int customerId) => $"DataDetails-{customerId}";

        public static string GetPagedListKey(int pageNumber, int pageSize) => $"DataList-{pageNumber}-{pageSize}";
    }
}
