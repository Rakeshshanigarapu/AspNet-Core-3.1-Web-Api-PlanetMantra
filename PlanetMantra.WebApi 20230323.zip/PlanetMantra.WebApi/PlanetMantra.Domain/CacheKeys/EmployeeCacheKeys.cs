﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.CacheKeys
{
    public static class EmployeeCacheKeys
    {
        public static string ListKey => "EmployeeList";

        public static string SelectListKey => "EmployeeSelectList";

        public static string GetByIdKey(int id) => $"Employee-{id}";
                
        public static string GetPagedListKey(int pageNumber, int pageSize, string searchText) => $"UserList-{pageNumber}-{pageSize}-{searchText}";

        public static string GetPagedListKey(int pageNumber, int pageSize, string searchText, string sort) => $"UserList-{pageNumber}-{pageSize}-{searchText}-{sort}";
    }
}
