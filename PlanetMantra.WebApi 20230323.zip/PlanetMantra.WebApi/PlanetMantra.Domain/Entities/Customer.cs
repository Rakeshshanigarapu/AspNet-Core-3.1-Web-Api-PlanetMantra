﻿using PlanetMantra.Domain.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.Entities
{
    public class Customer : AuditableEntity
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public int TotalCount { get; set; }
    }
    public class GetAllCustomersResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public int TotalCount { get; set; }
    }
    public class GetAllCustomersResponse2
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; } 
    }
    public class GetAllPagedCustomersResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public int FilteredTotalCount { get; set; }
        public int TotalCount { get; set; }
    }
}
