﻿using PlanetMantra.Domain.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.Entities
{
    public class Brand : AuditableEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Tax { get; set; }
    }
}
