﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.Entities
{
    //public class Users
    //{
    //    public int Id{ get; set; }
    //    public string Name { get; set; }
    //    public string EmailId { get; set; }
    //    public string Mobile { get; set; }
    //    public string Address { get; set; }
    //    public bool IsActive { get; set; }
    //}
    public class UserModel
    {
        public string User_Role { get; set; }
        public Guid User_UUID { get; set; }
        public string status { get; set; }
        public string Username { get; set; }
        public string F_Name { get; set; }
        public string M_Name { get; set; }
        public string L_Name { get; set; }
        public string Mobile_No { get; set; }
        public string Work_Email { get; set; }
        public string Job_Title { get; set; }
        public string Token { get; set; }
    }
    public class UserLogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
