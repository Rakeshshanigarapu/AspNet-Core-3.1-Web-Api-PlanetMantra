﻿using Microsoft.AspNetCore.Http;

namespace PlanetMantra.Domain.Entities
{
    public class AddEmployeeModel
    {
        public string EmployeeNo { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public IFormFile ProfileFile { get; set; }

    }
}
