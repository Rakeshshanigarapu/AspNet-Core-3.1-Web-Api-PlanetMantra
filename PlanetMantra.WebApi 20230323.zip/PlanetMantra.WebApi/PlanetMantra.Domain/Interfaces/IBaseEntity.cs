﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetMantra.Domain.Interfaces
{
    public interface IBaseEntity
    {
        int Id { get; set; } 
    }
}
